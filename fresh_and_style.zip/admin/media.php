<?php
/**
 * Created by PhpStorm.
 * User: ikkuh
 * Date: 12/12/2017
 * Time: 12:36
 */
include 'header.php';
?>

<h1>Media</h1>

<ul class="nav nav-tabs">
    <li class="nav-item">
        <a class="nav-link" href="upload.php">Media uploaden</a>
    </li>
</ul>

<?php include 'footer.php'; ?>
