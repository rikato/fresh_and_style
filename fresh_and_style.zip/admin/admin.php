<?php include "header.php"; ?>

<h1>Welkom  <?php getUser($dbcon); ?>.</h1>

<?php include "footer.php"; ?>